#ifndef BASE_H
#define BASE_H


#include "RTScene.h"
#include "Object.h"
#include "Shape.h"
#include "Camera.h"


#endif